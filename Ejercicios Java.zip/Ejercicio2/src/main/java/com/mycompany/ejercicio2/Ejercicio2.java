/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio2;

/**
 *
 * @author ghot-
 */
public class Ejercicio2 {

    public static void main(String[] args) {
        int numero1 = 10; // Puedes cambiar estos valores
        int numero2 = 5; // Puedes cambiar estos valores

        System.out.println("Suma: " + (numero1 + numero2));
        System.out.println("Resta: " + (numero1 - numero2));
        System.out.println("Multiplicación: " + (numero1 * numero2));
        System.out.println("División: " + (numero1 / numero2));
        System.out.println("Modulo: " + (numero1 % numero2));
    }
}
