/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio3;

/**
 *
 * @author ghot-
 */
public class Ejercicio3 {

    public static void main(String[] args) {
        int M = 6, T = 1, K = -10;
        System.out.println("M > T es " + (M > T));
        System.out.println("T / K == -5 es " + (T / K == -5));
        System.out.println("(M+T == 7) || (M-T == 5) es " + ((M+T == 7) || (M-T == 5)));
    }
}
