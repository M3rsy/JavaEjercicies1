/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio4;

/**
 *
 * @author ghot-
 */
public class Ejercicio4 {

    public static void main(String[] args) {
       String[] nombres = {"Nombre1", "Nombre2", "Nombre3", "Nombre4", "Nombre5", "Nombre6", "Nombre7", "Nombre8", "Nombre9", "Nombre10"};

        for(String nombre : nombres) {
            System.out.println(nombre);
    }
}
}